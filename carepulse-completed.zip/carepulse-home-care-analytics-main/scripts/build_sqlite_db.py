"""Build the CarePulse SQLite database from raw CSVs.

What it does
------------
1) Creates / resets database/carepulse.db using database/schema.sql
2) Loads data/raw/*.csv into the tables
3) Adds a few indexes for faster analytics queries

Run
---
python scripts/build_sqlite_db.py
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_schema(schema_path: Path) -> str:
    return schema_path.read_text(encoding="utf-8")


def main() -> None:
    root = repo_root()

    db_path = root / "database" / "carepulse.db"
    schema_path = root / "database" / "schema.sql"
    raw = root / "data" / "raw"

    if not schema_path.exists():
        raise FileNotFoundError(f"Missing schema at {schema_path}")

    for fname in ["clients.csv", "caregivers.csv", "services.csv", "visits.csv"]:
        if not (raw / fname).exists():
            raise FileNotFoundError(
                f"Missing {fname}. Run: python scripts/data_generation.py (creates data/raw/)")

    (root / "database").mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(db_path)
    try:
        conn.execute("PRAGMA foreign_keys = ON;")

        # Reset schema
        schema_sql = read_schema(schema_path)
        conn.executescript(
            "\n".join(
                [
                    "DROP TABLE IF EXISTS visits;",
                    "DROP TABLE IF EXISTS services;",
                    "DROP TABLE IF EXISTS caregivers;",
                    "DROP TABLE IF EXISTS clients;",
                    schema_sql,
                ]
            )
        )

        # Load CSVs
        clients = pd.read_csv(raw / "clients.csv")
        caregivers = pd.read_csv(raw / "caregivers.csv")
        services = pd.read_csv(raw / "services.csv")
        visits = pd.read_csv(raw / "visits.csv")

        clients.to_sql("clients", conn, if_exists="append", index=False)
        caregivers.to_sql("caregivers", conn, if_exists="append", index=False)
        services.to_sql("services", conn, if_exists="append", index=False)
        visits.to_sql("visits", conn, if_exists="append", index=False)

        # Helpful indexes
        conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_visits_visit_date ON visits(visit_date);
            CREATE INDEX IF NOT EXISTS idx_visits_client_id ON visits(client_id);
            CREATE INDEX IF NOT EXISTS idx_visits_caregiver_id ON visits(caregiver_id);
            """
        )
        conn.commit()

        print("✅ SQLite database built:")
        print(f"  - {db_path}")
        print("Tables: clients, caregivers, services, visits")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
