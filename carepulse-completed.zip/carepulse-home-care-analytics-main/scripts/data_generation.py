"""Generate synthetic home-care operational data for the CarePulse project.

This script creates 4 CSV files under data/raw/:
  - clients.csv
  - caregivers.csv
  - services.csv
  - visits.csv

Design goals
------------
* realistic-enough fields to support common agency KPIs
* deterministic output when a seed is provided
* safe to run from anywhere (paths are resolved relative to repo root)

Run
---
python scripts/data_generation.py --clients 200 --caregivers 40 --visits 1200 --seed 42
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
import random

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class Settings:
    num_clients: int
    num_caregivers: int
    num_visits: int
    seed: int


def repo_root() -> Path:
    # scripts/ is directly under repo root
    return Path(__file__).resolve().parents[1]


def ensure_dirs(root: Path) -> None:
    (root / "data" / "raw").mkdir(parents=True, exist_ok=True)
    (root / "data" / "processed").mkdir(parents=True, exist_ok=True)


def random_date_within(days_back: int) -> date:
    return (datetime.today() - timedelta(days=random.randint(1, days_back))).date()


def generate_clients(s: Settings) -> pd.DataFrame:
    # Enrollment happens in last ~3 years
    enrollment_dates = [random_date_within(1100) for _ in range(s.num_clients)]
    referral_sources = ["Hospital", "Physician", "Family", "Insurance", "Self"]

    clients = pd.DataFrame(
        {
            "client_id": np.arange(1, s.num_clients + 1),
            "age": np.random.randint(55, 96, size=s.num_clients),
            "gender": np.random.choice(["Male", "Female"], size=s.num_clients, p=[0.45, 0.55]),
            "enrollment_date": enrollment_dates,
            "referral_source": np.random.choice(referral_sources, size=s.num_clients),
        }
    )

    # Some clients discharge; others remain active (discharge_date is NULL)
    # Discharge after 1–12 months, or still active.
    discharge_choice = np.random.choice(
        ["active", 30, 60, 90, 120, 180, 240, 300, 365],
        size=s.num_clients,
        p=[0.35, 0.08, 0.10, 0.10, 0.10, 0.08, 0.07, 0.07, 0.05],
    )

    discharge_dates: list[date | None] = []
    for idx, days in enumerate(discharge_choice):
        if days == "active":
            discharge_dates.append(None)
        else:
            dt = pd.to_datetime(clients.loc[idx, "enrollment_date"]) + pd.Timedelta(days=int(days))
            discharge_dates.append(dt.date())
    clients["discharge_date"] = discharge_dates

    return clients


def generate_caregivers(s: Settings) -> pd.DataFrame:
    roles = ["RN", "LPN", "HHA"]
    caregivers = pd.DataFrame(
        {
            "caregiver_id": np.arange(1, s.num_caregivers + 1),
            "role": np.random.choice(roles, size=s.num_caregivers, p=[0.25, 0.35, 0.40]),
            "hire_date": [random_date_within(1800) for _ in range(s.num_caregivers)],
        }
    )

    # Hourly rate depends on role
    role_to_rate = {"RN": (32, 50), "LPN": (26, 38), "HHA": (18, 28)}
    rates = []
    for role in caregivers["role"]:
        lo, hi = role_to_rate[role]
        rates.append(np.random.randint(lo, hi + 1))
    caregivers["hourly_rate"] = rates

    return caregivers


def generate_services() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "service_id": [1, 2, 3, 4],
            "service_type": [
                "Personal Care",
                "Skilled Nursing",
                "Physical Therapy",
                "Companionship",
            ],
            # Typical planned duration
            "duration_hours": [2.0, 3.0, 1.5, 2.0],
            # A simple per-visit “charge” (not reimbursement)
            "cost": [60.0, 150.0, 110.0, 50.0],
        }
    )


def generate_visits(s: Settings, clients: pd.DataFrame, caregivers: pd.DataFrame, services: pd.DataFrame) -> pd.DataFrame:
    # Visits happen in the last year
    visit_dates = [random_date_within(365) for _ in range(s.num_visits)]

    visits = pd.DataFrame(
        {
            "visit_id": np.arange(1, s.num_visits + 1),
            "client_id": np.random.choice(clients["client_id"], size=s.num_visits),
            "caregiver_id": np.random.choice(caregivers["caregiver_id"], size=s.num_visits),
            "service_id": np.random.choice(services["service_id"], size=s.num_visits),
            "visit_date": visit_dates,
        }
    )

    # Hours: centered around service duration, with small noise + rounding to 0.5
    service_duration = services.set_index("service_id")["duration_hours"].to_dict()
    hrs = []
    for sid in visits["service_id"]:
        base = float(service_duration[int(sid)])
        noisy = max(0.5, np.random.normal(loc=base, scale=0.35))
        # Round to nearest 0.5
        hrs.append(round(noisy * 2) / 2)
    visits["hours"] = hrs

    return visits


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate synthetic CarePulse CSV datasets.")
    parser.add_argument("--clients", type=int, default=200, help="Number of clients")
    parser.add_argument("--caregivers", type=int, default=40, help="Number of caregivers")
    parser.add_argument("--visits", type=int, default=1200, help="Number of visits")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    s = Settings(args.clients, args.caregivers, args.visits, args.seed)

    np.random.seed(s.seed)
    random.seed(s.seed)

    root = repo_root()
    ensure_dirs(root)
    raw = root / "data" / "raw"

    clients = generate_clients(s)
    caregivers = generate_caregivers(s)
    services = generate_services()
    visits = generate_visits(s, clients, caregivers, services)

    clients.to_csv(raw / "clients.csv", index=False)
    caregivers.to_csv(raw / "caregivers.csv", index=False)
    services.to_csv(raw / "services.csv", index=False)
    visits.to_csv(raw / "visits.csv", index=False)

    print("✅ Synthetic CarePulse data generated:")
    print(f"  - {raw / 'clients.csv'}")
    print(f"  - {raw / 'caregivers.csv'}")
    print(f"  - {raw / 'services.csv'}")
    print(f"  - {raw / 'visits.csv'}")


if __name__ == "__main__":
    main()
