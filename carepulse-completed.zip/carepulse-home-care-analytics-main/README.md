# CarePulse – Home Care Operations Analytics

CarePulse is a small **end-to-end analytics project** that simulates a home-care agency dataset, stores it in **SQLite**, and produces a **KPI pack** (CSV outputs + charts) that can be plugged into **Power BI/Tableau**.

This repo is designed to be **simple, runnable, and portfolio-ready**.

## ✅ What you get

**Data (synthetic)**
- Clients (enrollment, discharge, referral source)
- Caregivers (role, hire date, hourly rate)
- Services (type, duration, cost)
- Visits (who served whom, when, and for how long)

**Outputs**
- SQLite database: `database/carepulse.db`
- KPI CSVs: `reports/*.csv`
- Charts: `reports/charts/*.png`

## ⚙️ Quick start

```bash
pip install -r requirements.txt
python scripts/run_pipeline.py
```

After running, open:
- `reports/kpi_summary.csv`
- `reports/visits_by_service.csv`
- `reports/clients_by_referral.csv`
- `reports/caregiver_utilization_top10.csv`
- charts in `reports/charts/`

## 🧱 Project structure

```
carepulse-home-care-analytics/
├─ database/
│  ├─ schema.sql
│  └─ carepulse.db              # generated
├─ data/
│  ├─ raw/                      # generated CSVs (synthetic)
│  └─ processed/                # reserved for future feature engineering
├─ reports/
│  ├─ *.csv                     # KPI outputs
│  └─ charts/                   # png charts
├─ scripts/
│  ├─ data_generation.py        # create synthetic data/raw/*.csv
│  ├─ build_sqlite_db.py         # build database/carepulse.db
│  ├─ sql_analytics.py           # quick ad-hoc SQL prints
│  ├─ kpi_report.py              # exports KPI CSVs + charts
│  └─ run_pipeline.py            # one-command runner
└─ requirements.txt
```

## 📈 Example KPIs included

- Total clients, active clients, total caregivers
- Total visits, total visit hours
- Gross service charges (simple `hours * cost` proxy)
- Visits/hours/charges by service type
- Clients by referral source
- Top 10 caregivers by total visit hours (utilization proxy)

## 🔜 Suggested next upgrades (if you want to take it further)

- Add a **calendar table** and compute weekly/monthly trends
- Build a **star schema** for BI (fact_visits + dim tables)
- Add SLA metrics: late visits, missed visits, cancellations
- Add a notebook and/or a Power BI `.pbix` template

---

If you want, tell me whether you’re using **Power BI** or **Tableau**, and I’ll give you a clean set of **BI-ready export tables** (fact + dims) and recommended visuals.
